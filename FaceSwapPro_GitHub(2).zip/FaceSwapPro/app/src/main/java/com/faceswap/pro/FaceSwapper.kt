package com.faceswap.pro

import android.graphics.Bitmap
import android.graphics.PointF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvException
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.MatOfFloat6
import org.opencv.core.MatOfInt
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.imgproc.Subdiv2D
import org.opencv.photo.Photo
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Landmark-based face swap:
 *  1. Delaunay triangulation of the base face's 468 landmarks (same triangle indices on both faces)
 *  2. Per-triangle affine warp of the replacement face onto the base face
 *  3. LAB mean/std colour transfer so skin tone and lighting match the base photo
 *  4. Poisson (seamless) cloning through the face-hull mask, or a feathered alpha blend as fallback
 */
object FaceSwapper {

    data class Options(val colorMatch: Boolean = true, val seamless: Boolean = true)

    /** Frees every tracked Mat when closed. */
    private class Tracker : AutoCloseable {
        private val mats = ArrayList<Mat>()
        fun <T : Mat> track(m: T): T { mats.add(m); return m }
        override fun close() { mats.forEach { it.release() }; mats.clear() }
    }

    /**
     * Puts the face from [face] onto the face in [base] and returns a new bitmap of the base's size.
     * Must be called after OpenCV has been initialised.
     */
    fun swap(
        face: Bitmap, facePts: List<PointF>,
        base: Bitmap, basePts: List<PointF>,
        options: Options = Options()
    ): Bitmap = Tracker().use { t ->
        val faceBgr = t.track(toBgr(face))
        val baseBgr = t.track(toBgr(base))
        val w = baseBgr.cols()
        val h = baseBgr.rows()

        val dst = basePts.map { Point(it.x.toDouble().coerceIn(0.0, w - 1.0), it.y.toDouble().coerceIn(0.0, h - 1.0)) }
        val src = facePts.map { Point(it.x.toDouble().coerceIn(0.0, faceBgr.cols() - 1.0), it.y.toDouble().coerceIn(0.0, faceBgr.rows() - 1.0)) }

        // 1 + 2: triangulate on the base face and warp every triangle of the replacement face
        val warped = t.track(Mat.zeros(baseBgr.size(), CvType.CV_8UC3))
        for (tri in delaunay(dst, w, h)) warpTriangle(faceBgr, warped, src, dst, tri)

        // Mask = convex hull of the base landmarks, slightly eroded to hide edge artefacts
        val dstInt = dst.map { Point(it.x.roundToInt().toDouble(), it.y.roundToInt().toDouble()) }
        val hullIdx = t.track(MatOfInt())
        Imgproc.convexHull(t.track(MatOfPoint(*dstInt.toTypedArray())), hullIdx)
        val hull = t.track(MatOfPoint(*hullIdx.toArray().map { dstInt[it] }.toTypedArray()))
        val mask = t.track(Mat.zeros(h, w, CvType.CV_8UC1))
        Imgproc.fillConvexPoly(mask, hull, Scalar(255.0))
        val hullRect = Imgproc.boundingRect(hull)
        val k = (hullRect.width * 0.04).roundToInt().coerceAtLeast(3) or 1
        val kernel = t.track(Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(k.toDouble(), k.toDouble())))
        Imgproc.erode(mask, mask, kernel)

        // 3: colour / lighting transfer
        val matched = if (options.colorMatch) matchColor(warped, baseBgr, mask, t) else warped

        // 4: blend
        val blended = t.track(
            if (options.seamless) {
                try {
                    val r = Imgproc.boundingRect(mask)
                    val center = Point((r.x + r.width / 2).toDouble(), (r.y + r.height / 2).toDouble())
                    Mat().also { Photo.seamlessClone(matched, baseBgr, mask, center, it, Photo.NORMAL_CLONE) }
                } catch (e: CvException) {
                    featherBlend(matched, baseBgr, mask, hullRect.width * 0.02, t)
                }
            } else {
                featherBlend(matched, baseBgr, mask, hullRect.width * 0.02, t)
            }
        )

        val rgba = t.track(Mat())
        Imgproc.cvtColor(blended, rgba, Imgproc.COLOR_BGR2RGBA)
        Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { Utils.matToBitmap(rgba, it) }
    }

    // ---------------------------------------------------------------- helpers

    private fun toBgr(bmp: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val bgr = Mat()
        Imgproc.cvtColor(rgba, bgr, Imgproc.COLOR_RGBA2BGR)
        rgba.release()
        return bgr
    }

    private fun key(x: Float, y: Float): Long =
        (x.toRawBits().toLong() shl 32) or (y.toRawBits().toLong() and 0xFFFFFFFFL)

    /** Delaunay triangles as index triples into [pts]. */
    private fun delaunay(pts: List<Point>, w: Int, h: Int): List<IntArray> {
        val subdiv = Subdiv2D(Rect(0, 0, w, h))
        val index = HashMap<Long, Int>(pts.size * 2)
        pts.forEachIndexed { i, p ->
            val k = key(p.x.toFloat(), p.y.toFloat())
            if (!index.containsKey(k)) {
                index[k] = i
                subdiv.insert(p)
            }
        }
        val list = MatOfFloat6()
        subdiv.getTriangleList(list)
        val arr = list.toArray()
        list.release()

        val out = ArrayList<IntArray>(arr.size / 6)
        var i = 0
        while (i + 5 < arr.size) {
            val a = index[key(arr[i], arr[i + 1])]
            val b = index[key(arr[i + 2], arr[i + 3])]
            val c = index[key(arr[i + 4], arr[i + 5])]
            if (a != null && b != null && c != null) out.add(intArrayOf(a, b, c))
            i += 6
        }
        return out
    }

    private fun clip(r: Rect, w: Int, h: Int): Rect {
        val x0 = r.x.coerceIn(0, w)
        val y0 = r.y.coerceIn(0, h)
        val x1 = (r.x + r.width).coerceIn(0, w)
        val y1 = (r.y + r.height).coerceIn(0, h)
        return Rect(x0, y0, x1 - x0, y1 - y0)
    }

    private fun warpTriangle(srcImg: Mat, dstImg: Mat, src: List<Point>, dst: List<Point>, tri: IntArray) {
        Tracker().use { t ->
            val s = tri.map { src[it] }
            val d = tri.map { dst[it] }

            val sRect = clip(Imgproc.boundingRect(t.track(MatOfPoint2f(*s.toTypedArray()))), srcImg.cols(), srcImg.rows())
            val dRect = clip(Imgproc.boundingRect(t.track(MatOfPoint2f(*d.toTypedArray()))), dstImg.cols(), dstImg.rows())
            if (sRect.width < 1 || sRect.height < 1 || dRect.width < 1 || dRect.height < 1) return

            val sLocal = t.track(MatOfPoint2f(*s.map { Point(it.x - sRect.x, it.y - sRect.y) }.toTypedArray()))
            val dLocal = t.track(MatOfPoint2f(*d.map { Point(it.x - dRect.x, it.y - dRect.y) }.toTypedArray()))
            val m = t.track(Imgproc.getAffineTransform(sLocal, dLocal))

            val srcCrop = t.track(srcImg.submat(sRect))
            val patch = t.track(Mat())
            Imgproc.warpAffine(srcCrop, patch, m, dRect.size(), Imgproc.INTER_LINEAR, Core.BORDER_REFLECT_101)

            val triMask = t.track(Mat.zeros(dRect.size(), CvType.CV_8UC1))
            val poly = t.track(
                MatOfPoint(*d.map { Point((it.x - dRect.x).roundToInt().toDouble(), (it.y - dRect.y).roundToInt().toDouble()) }.toTypedArray())
            )
            Imgproc.fillConvexPoly(triMask, poly, Scalar(255.0))

            val dstRoi = t.track(dstImg.submat(dRect))
            patch.copyTo(dstRoi, triMask)
        }
    }

    /** Shifts [src] colours (in LAB) so their mean/std inside [mask] match [ref]. */
    private fun matchColor(src: Mat, ref: Mat, mask: Mat, t: Tracker): Mat {
        val s32 = t.track(Mat())
        val r32 = t.track(Mat())
        src.convertTo(s32, CvType.CV_32FC3, 1.0 / 255.0)
        ref.convertTo(r32, CvType.CV_32FC3, 1.0 / 255.0)
        val sLab = t.track(Mat())
        val rLab = t.track(Mat())
        Imgproc.cvtColor(s32, sLab, Imgproc.COLOR_BGR2Lab)
        Imgproc.cvtColor(r32, rLab, Imgproc.COLOR_BGR2Lab)

        val sMean = MatOfDouble(); val sStd = MatOfDouble()
        val rMean = MatOfDouble(); val rStd = MatOfDouble()
        Core.meanStdDev(sLab, sMean, sStd, mask)
        Core.meanStdDev(rLab, rMean, rStd, mask)
        val sm = sMean.toArray(); val ss = sStd.toArray()
        val rm = rMean.toArray(); val rs = rStd.toArray()
        listOf(sMean, sStd, rMean, rStd).forEach { it.release() }

        val channels = ArrayList<Mat>()
        Core.split(sLab, channels)
        channels.forEach { t.track(it) }
        for (c in 0..2) {
            val scale = (rs[c] / max(ss[c], 1e-3)).coerceIn(0.7, 1.3)
            channels[c].convertTo(channels[c], -1, scale, rm[c] - sm[c] * scale)
        }
        Core.merge(channels, sLab)
        Imgproc.cvtColor(sLab, s32, Imgproc.COLOR_Lab2BGR)

        val out = t.track(Mat())
        s32.convertTo(out, CvType.CV_8UC3, 255.0)
        return out
    }

    /** Plain alpha blend with a Gaussian-feathered mask. */
    private fun featherBlend(fg: Mat, bg: Mat, mask: Mat, sigma: Double, t: Tracker): Mat {
        val soft = t.track(Mat())
        Imgproc.GaussianBlur(mask, soft, Size(0.0, 0.0), max(sigma, 1.0))
        val a = t.track(Mat())
        soft.convertTo(a, CvType.CV_32F, 1.0 / 255.0)
        val a3 = t.track(Mat())
        Core.merge(listOf(a, a, a), a3)

        val inv = t.track(Mat())
        Core.multiply(a3, Scalar(-1.0, -1.0, -1.0), inv)
        Core.add(inv, Scalar(1.0, 1.0, 1.0), inv)

        val f = t.track(Mat())
        val b = t.track(Mat())
        fg.convertTo(f, CvType.CV_32FC3)
        bg.convertTo(b, CvType.CV_32FC3)
        Core.multiply(f, a3, f)
        Core.multiply(b, inv, b)
        Core.add(f, b, f)

        val out = Mat()
        f.convertTo(out, CvType.CV_8UC3)
        return out
    }
}
