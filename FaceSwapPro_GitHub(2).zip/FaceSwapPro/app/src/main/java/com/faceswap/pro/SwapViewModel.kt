package com.faceswap.pro

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class UiState(
    val base: Bitmap? = null,      // photo whose face gets replaced
    val face: Bitmap? = null,      // face that is placed onto the base photo
    val result: Bitmap? = null,
    val busy: Boolean = false,
    val strength: Float = 1f,
    val colorMatch: Boolean = true,
    val seamless: Boolean = true,
    @StringRes val messageRes: Int? = null,
)

class SwapViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val work = Mutex()
    private var detector: FaceLandmarkDetector? = null
    private var basePts: List<PointF>? = null
    private var facePts: List<PointF>? = null
    private var swapped: Bitmap? = null   // full-strength swap result
    private var mixJob: Job? = null

    private fun detector(): FaceLandmarkDetector =
        detector ?: FaceLandmarkDetector(getApplication()).also { detector = it }

    fun setBase(uri: Uri) = loadImage(uri, isBase = true)
    fun setFace(uri: Uri) = loadImage(uri, isBase = false)

    private fun loadImage(uri: Uri, isBase: Boolean) {
        viewModelScope.launch(Dispatchers.Default) {
            work.withLock {
                _state.update { it.copy(busy = true) }
                try {
                    val bmp = ImageUtils.load(getApplication(), uri)
                    val pts = detector().detect(bmp)
                    swapped = null
                    if (isBase) {
                        basePts = pts
                        _state.update { it.copy(base = bmp, result = null) }
                    } else {
                        facePts = pts
                        _state.update { it.copy(face = bmp, result = null) }
                    }
                    if (pts == null) postMessage(R.string.err_no_face)
                } catch (e: Exception) {
                    postMessage(R.string.err_generic)
                } finally {
                    _state.update { it.copy(busy = false) }
                }
            }
        }
    }

    fun swapRoles() {
        viewModelScope.launch(Dispatchers.Default) {
            work.withLock {
                val s = _state.value
                val tmp = basePts; basePts = facePts; facePts = tmp
                swapped = null
                _state.update { it.copy(base = s.face, face = s.base, result = null) }
            }
        }
    }

    fun swap() {
        viewModelScope.launch(Dispatchers.Default) { work.withLock { runSwap() } }
    }

    private fun runSwap() {
        val s = _state.value
        val base = s.base
        val face = s.face
        if (base == null || face == null) { postMessage(R.string.err_pick_both); return }
        val bp = basePts
        val fp = facePts
        if (bp == null || fp == null) { postMessage(R.string.err_no_face); return }

        _state.update { it.copy(busy = true) }
        try {
            val out = FaceSwapper.swap(face, fp, base, bp, FaceSwapper.Options(s.colorMatch, s.seamless))
            swapped = out
            _state.update { it.copy(result = mix(base, out, it.strength)) }
        } catch (e: Throwable) {
            postMessage(R.string.err_generic)
        } finally {
            _state.update { it.copy(busy = false) }
        }
    }

    fun setStrength(value: Float) {
        _state.update { it.copy(strength = value) }
        val out = swapped ?: return
        val base = _state.value.base ?: return
        mixJob?.cancel()
        mixJob = viewModelScope.launch(Dispatchers.Default) {
            val mixed = mix(base, out, value)
            _state.update { it.copy(result = mixed) }
        }
    }

    fun setColorMatch(on: Boolean) {
        _state.update { it.copy(colorMatch = on) }
        if (swapped != null) swap()
    }

    fun setSeamless(on: Boolean) {
        _state.update { it.copy(seamless = on) }
        if (swapped != null) swap()
    }

    fun save() {
        val result = _state.value.result ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val uri = ImageUtils.saveToGallery(getApplication(), result)
            postMessage(if (uri != null) R.string.saved else R.string.err_generic)
        }
    }

    fun consumeMessage() = _state.update { it.copy(messageRes = null) }

    private fun postMessage(@StringRes res: Int) = _state.update { it.copy(messageRes = res) }

    /** Cross-fades the swapped image over the base photo. */
    private fun mix(base: Bitmap, over: Bitmap, strength: Float): Bitmap {
        if (strength >= 0.999f) return over
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = (strength.coerceIn(0f, 1f) * 255).toInt() }
        Canvas(out).drawBitmap(over, 0f, 0f, paint)
        return out
    }

    override fun onCleared() {
        detector?.close()
        super.onCleared()
    }
}
