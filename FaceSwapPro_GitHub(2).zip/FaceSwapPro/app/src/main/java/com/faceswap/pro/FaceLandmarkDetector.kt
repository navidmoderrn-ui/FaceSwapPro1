package com.faceswap.pro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import kotlin.math.max
import kotlin.math.min

/** Wraps MediaPipe Face Landmarker and returns the 468 face-mesh points in pixel coordinates. */
class FaceLandmarkDetector(context: Context) : AutoCloseable {

    private val landmarker: FaceLandmarker

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath(MODEL_ASSET)
            .build()
        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setNumFaces(5)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .build()
        landmarker = FaceLandmarker.createFromOptions(context, options)
    }

    /** Returns landmarks of the largest face in the image, or null if no face was found. */
    fun detect(bitmap: Bitmap): List<PointF>? {
        val result = landmarker.detect(BitmapImageBuilder(bitmap).build())
        val faces = result.faceLandmarks()
        if (faces.isEmpty()) return null

        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()

        val largest = faces.maxByOrNull { lms ->
            var minX = Float.MAX_VALUE
            var minY = Float.MAX_VALUE
            var maxX = -Float.MAX_VALUE
            var maxY = -Float.MAX_VALUE
            for (i in 0 until POINTS) {
                minX = min(minX, lms[i].x()); maxX = max(maxX, lms[i].x())
                minY = min(minY, lms[i].y()); maxY = max(maxY, lms[i].y())
            }
            (maxX - minX) * (maxY - minY)
        } ?: return null

        return List(POINTS) { i -> PointF(largest[i].x() * w, largest[i].y() * h) }
    }

    override fun close() {
        landmarker.close()
    }

    companion object {
        const val MODEL_ASSET = "face_landmarker.task"
        const val POINTS = 468 // the model also returns 10 iris points; we ignore them
    }
}
